WSBM Code README 

Reference:
	Aicher, Christopher, Abigail Z. Jacobs, and Aaron Clauset. “Adapting the Stochastic Block Model to Edge-Weighted Networks.” (2013).  arXiv:1305.5782) http://arxiv.org/abs/1305.5782.

Download all the Code:
	Get the most up-to-date versions of the complete implementations at http://tuvalu.santafe.edu/~aaronc/wsbm/
	
Brief File Overview: 
    wsbm.m - The main function for inferring community structure.
	
	setup_distr.m - A helper function for selecting exponential family distributions to use in the wsbm.m model. This function is required function for wsbm.m to work properly.
	
    Adj2Edg.m, Edg2Adj.m - Helper functions for converting between adjacency matrices and edge lists. These functions are required for wsbm.m to work properly.
	
    .private - A folder containing MATLAB and MEX files that are used privately by wsbm.m. This is a required folder for wsbm.m to work properly. 
	
	InstallMEXFiles.m - A script file detailing how to install optional (but highly recommended) MEX functions (in the private folder) for wsbm.m to use. 
	
	WSBMDemo.m - Demo Script File
	This script file demonstrates examples of how to use wsbm.m

	plotMu.m - Visualizing the Posterior Vertex-Label Probabilities
	This function visualizes the posterior label probabilities each vertex.

	plotWSBM.m - Visualizing Adjacency Matrices
	This function visualizes the block structure of the network using the labels inferred.

	generateEdges.m - Generate Synthetic Networks
	This function generates synthetic networks. It is for advanced users and requires the helper functions of wsbm.m. 


Type 'help <filename>' for specific information in MATLAB.

A note about MATLAB compatibility
	The MATLAB functions were designed to be compatible with MATLAB v7.13 (2011). They are not necessarily compatible with older versions of Matlab.
	Also see InstallMEXFiles.m for details on how to install optional (but highly recommended) MEX functions for wsbm.m to use.
	
Finally, if you use our code in an academic publication, it would be courteous of you to thank us in your acknowledgements for providing you with implementations of the methods.

Version 1.0 | December 2013 | Christopher Aicher
