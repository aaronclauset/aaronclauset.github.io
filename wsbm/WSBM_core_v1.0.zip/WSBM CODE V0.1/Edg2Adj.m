function [Adj_matrix,NumEdges] = Edg2Adj(Edge_List)
%EDG2ADJ converts an Edge List into an Adjacency Matrix 
%   
%   EDG2ADJ(Edge_List) converts Edge_List into an average adjacency matrix
%   Adj_matrix and counts the number of edges in the adjacency matrix
%   NumEdges. 
%
%   Examples:
%       [Adj_matrix,NumEdges] = Edg2Adj(Edge_List)
%
%   Inputs:
%       Edg_list - mx3 matrix of (parent, child, weight)
%   Outputs:
%       Adj_matrix - nxn matrix, weighted average with NaN for non-edges
%       NumEdges - nxn matrix, counts of the edges
%      
%   See also ADJ2EDG

% EDG2ADJ comes with ABSOLUTELY NO WARRANTY
% Version 1.0 | December 2013 | Christopher Aicher


[m,~] = size(Edge_List);
n = max(max(Edge_List(:,1:2)));
NumEdges = zeros(n,n);
Adj_matrix = zeros(n,n);
for ee = 1:m,
    NumEdges(Edge_List(ee,1),Edge_List(ee,2)) = ...
        NumEdges(Edge_List(ee,1),Edge_List(ee,2))+1;
    Adj_matrix(Edge_List(ee,1),Edge_List(ee,2)) = ...
        Adj_matrix(Edge_List(ee,1),Edge_List(ee,2))+Edge_List(ee,3); 
end

Adj_matrix = Adj_matrix./NumEdges;
Adj_matrix(NumEdges(:) == 0) = NaN;

end