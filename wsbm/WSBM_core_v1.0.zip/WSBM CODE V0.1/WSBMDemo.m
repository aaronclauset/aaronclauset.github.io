% WSBMDEMO Demo Script for the WSBM
%   Press Ctrl + Enter in each (%%) cell to execute the code
% See also WSBM
% Version 1.0 | January 2014 | Christopher Aicher

%% Add Analysis Tool Dir
addpath('analysis tools'); 

%% Install MEX Files (Optional)
InstallMEXFiles

%% Simple Example----------------------------------------------------------
%% Make Adj_Matrix
% A is a 20x20 Adjacency Matrix for two groups of 10 vertices each,
% Edges within groups have weight 1 and edges between groups have weight 0
A = [ones(10,10),zeros(10,10);
     zeros(10,10),ones(10,10)];
% Visualization of the Adjacency Matrix A
plotWSBM(A);
title('Synthetic Data Adjacency Matrix');
%% Infer Truth
% Run the inference on A for 2 groups
Labels = wsbm(A,2);
% Display the inferred labels
disp('Labels:');
disp(Labels');
%% Shuffled Adj_Matrix
% Shuffle the numbering of the vertices of A 
%  (i.e. permute the rows and columns)
Ashuffle = shuffle(A);
plotWSBM(Ashuffle);
title('Shuffled Synthetic Data Adjacency Matrix');
%% Infer Truth
% Run the inference on Ashuffle for 2 groups
Labels = wsbm(Ashuffle,2);
% Display the inferred labels
disp('Labels:');
disp(Labels');

%% NFL Example-------------------------------------------------------------
%% Load Data
% Loads an NFL scoring network, E, as an edge list.
% This network has 2 types of information between pairs of teams: 
%   1. games played - edge-existence information
%   2. points scored - edge-weight information
load('Demo\nfl.mat'); 
% Visualize the edge list:
%  Colors correspond to points scored
%  White indicates the lack of a game played between two teams
plotWSBM(E);
title('NFL 2009 Scoring Network');

%% Find `Conference' Edge Structure
% Run the inference on E for 2 groups only using edge information  
[Edge_Label,Edge_Model] = wsbm(E,2,'W_Distr','None','E_Distr','Poisson');
% Plot Label Posterior Probabilities
subplot(1,2,1);
plotMu(Edge_Model);
% Plot E sorted by Labels (using MAP estimator)
subplot(1,2,2);
plotWSBM(Edge_Model);
title('Adjacency Matrix (Permuted by Edge Labels)');
%% Find `Skill' Weight Structure
% Run the inference on E for 2 groups only using weight information  
[Weight_Label,Weight_Model] = wsbm(E,2,'W_Distr','Normal','E_Distr','None'); 
% Plot Label Posterior Probabilities
subplot(1,2,1);
plotMu(Weight_Model);
% Plot E sorted by Labels (using MAP estimator)
subplot(1,2,2);
plotWSBM(Weight_Model);
title('Adjacency Matrix (Permuted by Weight Labels)');

%% 2 Group Weighted Network Example----------------------------------------
%% Generate Random Synthetic Data
[Edge_List,True_Model] = generateEdges();
plotWSBM(True_Model);
title('Synthetic Data Adjacency Matrix');
%% Fit WSBM
num_groups = 2; 
[Labels, Model] =  wsbm(Edge_List,num_groups);
plotWSBM(Model);
title('Inferred Permuted Adjacency Matrix');

%% 4 Group Mixed Network Example-------------------------------------------
%% Generate Data
% Advanced User Stuff -> It creates an interesting dataset
R = [1,2,3,4; 
     2,1,4,3; 
     3,4,1,2;
     4,3,2,1];
theta_w = [100,1;100,1; 0,1; 0,1];
theta_e = [0.1; 0.9; 0.1; 0.9];
group_sizes = [25;25;25;25];
[~,True_Model] = generateEdges('Normal','Bernoulli',R,theta_w,theta_e,group_sizes);
plotWSBM(True_Model);
title('Synthetic Data');
%% Fit Edge Model
[~,Edge_Model] = wsbm(True_Model.Data.Raw_Data,2,'W_Distr','None','E_Distr','Bernoulli'); 
subplot(1,2,1);
plotMu(Edge_Model);
subplot(1,2,2);
plotWSBM(Edge_Model);
title('Edge Model Permuted Adjacency Matrix')
%% Fit Weight Model
[~,Weight_Model] = wsbm(True_Model.Data.Raw_Data,2,'W_Distr','Normal','E_Distr','None'); 
subplot(1,2,1);
plotMu(Weight_Model);
subplot(1,2,2);
plotWSBM(Weight_Model);
title('Weight Model Permuted Adjacency Matrix')
%% Fit Mixed Model
[~,Mixed_Model] = wsbm(True_Model.Data.Raw_Data,4);
subplot(1,2,1);
plotMu(Mixed_Model);
subplot(1,2,2);
plotWSBM(Mixed_Model);
title('Mixed Model Permuted Adjacency Matrix')

