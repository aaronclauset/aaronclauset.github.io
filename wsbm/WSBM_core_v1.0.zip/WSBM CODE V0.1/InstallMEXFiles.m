%% Installing WSBM MEX files
% Run INSTALLMEXFILES to create MEX files in the private folder 
%   for WSBM to use
% Q&A:
% Q: What are MEX files?
% A: MATLAB's way of mixing complied C++ code with MATLAB. 
%    See 'mex -help'. Also see:
%    http://www.mathworks.com/help/matlab/matlab_external/introducing-mex-files.html
%
% Q: Why should I install MEX files?
% A1: Although MATLAB is fast at matrix computation, the inner computation
%     loops of WSBM can be replaced with C++ for a significant speed up.
% A2: The WSBM algorithm using MATLAB scales quadratically in the number of
%     vertices. The WSBM algorithm using MEX files scales linearly in the
%     number of edges. For sparse graphs, this can be significant.
%
% Q: How do I install MEX files?
% A: MATLAB is can be a bit picky about the specific complier and operating
%    system. Try 'mex -setup' to select a compatible complier. 
%    For more information see: 
%    http://www.mathworks.com/help/matlab/matlab_external/building-mex-files.html

%
% Version 1.0 | December 2013 | Christopher Aicher

% Install VB MEX Files
mex -outdir private private\create_T_w.cpp
mex -outdir private private\create_T_e.cpp
mex -outdir private private\calc_T_e_bra.cpp
mex -outdir private private\calc_T_w_bra.cpp
mex -outdir private private\vb_wsbm.cpp
% Install BP MEX files
mex -outdir private private\create_T_bp.cpp
mex -outdir private private\bp_wsbm.cpp