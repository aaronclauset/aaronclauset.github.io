function [Edge_list] = Adj2Edg(Adj_matrix)
%ADJ2EDG converts an Adjacency Matrix into an Edge List 
%   
%   ADJ2EDG(Adj_matrix,symmetric) converts Adj_matrix into an edge list 
%   Edge_list treating NaNs as non-edges. 
%
%   Examples:
%       [Edge_list] = Adj2Edg(Adj_matrix)
% 
%   Inputs:
%       Adj_matrix - nxn matrix, with NaN for non-edges
%       symmetric - 0 directed (default), 1 symmetric
%
%   Outputs:
%       Edge_list - mx3 matrix of (parent, child, weight)
%      
%   See also EDG2ADJ

% ADJ2EDG comes with ABSOLUTELY NO WARRANTY
% Version 1.0 | December 2013 | Christopher Aicher
[ntemp,mtemp] = size(Adj_matrix);
if ntemp ~= mtemp,
    if mtemp == 3,
        fprintf('Warning: Input already an Edge List\n');
        Edge_list = Adj_matrix;
        return
    end
    error('Adj Matrix is not square.\n');
end

[Is,Js] = find(~isnan(Adj_matrix));
Edge_list = [Is,Js,Adj_matrix(~isnan(Adj_matrix(:)))];


end