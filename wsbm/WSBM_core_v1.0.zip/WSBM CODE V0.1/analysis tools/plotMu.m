function [] = plotMu(Model)
%PLOTMU plots the posterior probability of vertex-label assignments. 
%
%   PLOTMU(Model) generates a IMAGESC plot of mu, the posterior probability
%   of vertex-label assigments. Each row is a vertex and each column is a
%   group. Ideally the posterior for each vertex is concentrated into one
%   group. If a vertex has a uniform or dispersed posterior, this indicates
%   a lack of fit or indecision in assigning a label.
%
%   Example:
%       [Label,Model] = wsbm(Raw_Data,k);
%       plotMu(Model)
%   Input:
%       mu   - kxn mat ~ mu(g,v) is the prob of vertex v belongs to group g
%   Output:
%       A IMAGESC plot. 
%
%   See also WSBM, PLOTWSBM

% PLOTMU comes with ABSOLUTELY NO WARRANTY
% Version 1.0 | December 2013 | Christopher Aicher
 

if isstruct(Model),
    mu = Model.Para.mu;
elseif isnumeric(Model),
    mu = Model;
else
    error('Unrecognized Input for Model');
end

opengl('software');
imagesc(mu');
title('Vertex-Label Posterior Plot');
xlabel('Probability in Group');
ylabel('Vertex');
colorbar
caxis([0 1]);
end