////////////////////////////////////////////////////////////////////////
// --- COPYRIGHT NOTICE ---------------------------------------------
// LocalCommunity - infers local community structure of networks
// Copyright (C) 2005 Aaron Clauset
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// See http://www.gnu.org/licenses/gpl.txt for more details.
// 
////////////////////////////////////////////////////////////////////////
// Author       : Aaron Clauset  (aaron@cs.unm.edu)				//
// Location     : University of New Mexico						//
// Time         : Winter 2005									//
// Advisor      : Dr. Cris Moore (moore@cs.unm.edu)				//
////////////////////////////////////////////////////////////////////////
// --- DEEPER DESCRIPTION ---------------------------------------------
//  see http://www.arxiv.org/abs/physics/0503036 for more information
// 
//  - reads graph structure from data file
//  - builds sparse adjacency matrix representation
//  - runs local community inference algorithm as published
//  - records R(t) function to file
//  - (optional) records subgraph structure with R(t) on edges
//
////////////////////////////////////////////////////////////////////////
// --- PROGRAM USAGE NOTES ---------------------------------------------
// This program is rather complicated so some notes on how to use it are
// in order. Mainly, the program requires a specific structure input file
// (.pairs) that has the following characteristics:
//  
//  1. .pairs is a list of tab-delimited pairs of numeric indices such as
//		"54\t91\n"
//  2. the network given is a single component
//  3. there are *no* self-loops or multi-edges in the file; you can use
//     the 'netstats' utility to extract the giantcomponent (-gcomp.pairs)
//     and then use that file as input to this program
//  4. the minimum node id in the input file must be 0; the maximum can be
//     anything (the program will infer it from the input file)
// 
// Description of commandline arguments
// -f <filename>    give the target .pairs file to be processed
// -k <int>		number of steps to run the algorithm
// -s <int>		(optional) initial vertex (default: random one)
// -NET			(optional) record a subgraph
// -GROUPS		(optional) record list of vertices in group
// -JOINS			(optional) record list of joins
// -l <text>		the text label for this run; used to build output filenames
// 
////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <string>
#include "stdlib.h"
#include "time.h"
#include "math.h"

#include "MersenneTwister.h"

using namespace std;

// ------------------------------------------------------------------------------------
// List object - simple linked list of integers
class list {
public:
	int		index;				// node index
	bool		touched;				// already touched big
	list		*next;				// pointer to next element in linked list
	list();   ~list();
};
list::list()  { index= 0; touched = false; next = NULL; }
list::~list() {}

// ------------------------------------------------------------------------------------
// Edge object - defined by a pair of vertex indices and *edge pointer to next in linked-list
class edge {
public:
	int		so;					// originating node
	int		si;					// terminating node
	edge		*next;				// pointer for linked list of edges
	
	edge();						// default constructor
	~edge();						// default destructor
};
edge::edge()  { so = 0; si = 0; next = NULL; }
edge::~edge() {}

// ------------------------------------------------------------------------------------
// Vertex object
enum {L_UNKNOWN, L_PERIPHERY, L_BOUNDARY, L_INTERIOR};
class vertex {
public:
	int		index;				// index of vertex
	list		*PL;					// (in P) list of vertices in my L group
	list		*PR;					// (in P) list of vertices in my R group
	list		*BL;					// (in B) list of vertices in P
	list		*PLend;				// pointer to end of PL*
	list		*PRend;				// pointer to end of PR*
	list		*BLend;				// pointer to end of BL*
	int		sPL;					// size of *PL list
	int		sPR;					// size of *PR list
	int		sBL;					// size of *BL list
	int		time;				// time added to L_BOUNDARY
	short int loc;					// location (L_UNKNOWN, L_PERIPHERY, L_BOUNDARY, or L_INTERIOR)
	
	vertex();						// default constructor
	~vertex();					// default destructor
};
vertex::vertex()  { index = 0; PL = NULL; PR = NULL; BL = NULL; PLend = NULL; PRend = NULL; BLend = NULL; sPL = 0; sPR = 0; sBL = 0; time = 2147483647; loc = L_UNKNOWN; }
vertex::~vertex() {
	list *current, *garbage;
	if (sPL > 0) { current = PL; while (current != NULL) { garbage = current; current = current->next; delete garbage; } } PLend = NULL;
	if (sPR > 0) { current = PR; while (current != NULL) { garbage = current; current = current->next; delete garbage; } } PRend = NULL;
	if (sBL > 0) { current = BL; while (current != NULL) { garbage = current; current = current->next; delete garbage; } } BLend = NULL;
}

// ------------------------------------------------------------------------------------
// tuple object - defined by an real value (e.g., dQ), (row,col) indices, and heap array[] index
struct tuple {
	double    value;				// stored value
	int		target;				// row index
	double    x;					// 
	double    y;					// 
	double    Z;					// 
};

// ------------------------------------------------------------------------------------
// ordered pair structures (handy in the program)
struct apair { int x; int y; };
struct dpair { int x; double y; };

// ------------------------------------------------------------------------------------
// FUNCTION DECLARATIONS --------------------------------------------------------------

void		adjustBoundary();
void		bootStrap();
void		buildFilenames();
void		collectFullStatistics();
tuple	computeDeltaRj(const int j);
void		countDegrees();
tuple	findMaxDeltaR();
bool		parseCommandLine(int argc,char * argv[]);
void		readInputFile();
void		recordGroups(const int tmax, const double Rmax);
void		recordSubGraph(const int tmax, const double Rmax);
void		resetVertices();
void		showPairsList();
dpair	updateRStats(dpair Rmax);
void		writeToJoinsFile(const bool flag);
void		writeToStatsFile(const bool flag);
void		writeToTerminal(const bool flag);

// ------------------------------------------------------------------------------------
// PROGRAM PARAMETERS -----------------------------------------------------------------

struct netparameters {
	int			n;				// number of nodes in network
	int			m;				// number of edges in network
	int			v;				// ego-centric node (internal indexing)
	int			maxid;			// maximum node id
	int			minid;			// minimum node id
}; netparameters    gparm;

struct outparameters {
	short int		textFlag;			// console output flag
	bool			netFlag;			// whether to write-out subgraph at R_max
	bool			joinsFlag;		// whether to write-out the joins file
	bool			groupsFlag;		// whether to write-out the groups file
	bool			statsFlag;		// whether to do full-network statistics
	bool			randFlag;			// how to choose for full-network statistics
	short int		fileFlag;			// enum'd filesystem flag

	string		filename;			// name of input file
	string		d_in;			// (dir ) directory for input file
	string		d_out;			// (dir ) director for output file

	string		f_input;			// (file) input data file
	string		f_parm;			// (file) parameters output
	string		f_joins;			// (file) time-ordered list of joins
	string		f_Rt;			// (file) R as a function of t
	string		f_net;			// (file) .pairs file for network at R_max
	string		f_group;			// (file) .list of indices in ego-community at R_max
	string		f_stats;			// (file) statistics for locality by degree
	string		f_statlist;		// (file) event statistics for locality by degree

	string		s_label;			// (temp) text label for run
	string		s_scratch;		// (temp) text for building filenames
	int			timer;			// timer for displaying progress reports 
	bool			timerFlag;		// flag for setting timer
	int			tf;				// maximum number of nodes to explore
	int			v;				// ego-centric node (external indexing)
	int			r;				// number of random samples
	int			mapNums;			// whether to remap vertex indices
}; outparameters	ioparm;

// ------------------------------------------------------------------------------------
// ----------------------------------- GLOBAL VARIABLES -------------------------------

char		pauseme;
vertex    *v;				// list of vertices
edge		*e;				// symmetric adjacency matrix (sparse)
edge		*elist;			// list of edges for *e
double    *degs;			// degree of each vertex
tuple	dRmax;			// maximal dR_j value for this round
edge		*ne;				// list of edges to neighbors of C
edge		*nelast;			// pointer to last edge in *ne list
dpair	*R;				// R[t] (R as function of time) and the joined vertex
double	*dR;				// dR[t] (dR/dt)
double    *To;				// To[t] (number of edges with 1+ endpoint in B)
int		t;				// time
double	*LS;				// mean R(t) over k steps as function of degree of v_o
double	*LSv;			// variance of LS
double	*LSc;			// count of number of vertices of degree i seen so far
int		maxdeg;			// maximum degree in graph
int		mindeg;			// minimum degree in graph
int		*degree;			// vertex degrees

MTRand    mtr;				// Mersenne Twister random number generator instance
enum {NONE};

// ------------------------------------------------------------------------------------
// ----------------------------------- MAIN PROGRAM -----------------------------------
int main(int argc,char * argv[]) {

	// default values for parameters which may be modified from the commandline
	ioparm.v			= 0;
	ioparm.r			= 1;
	ioparm.timer		= 20;
	ioparm.fileFlag	= NONE;
	ioparm.netFlag		= false;
	ioparm.joinsFlag    = false;
	ioparm.statsFlag    = false;
	ioparm.randFlag	= false;
	ioparm.groupsFlag   = false;
	ioparm.textFlag	= 0;
	ioparm.filename	= "community.pairs";
	ioparm.s_label		= "a";
	time_t t1;    t1 = time(&t1);
	time_t t2;    t2 = time(&t2);
	
	// ----------------------------------------------------------------------
	// Parse the command line, build filenames and then import the .pairs file
	cout << "LOCAL-COMMUNITY INFERENCE (B-version)\n";
	if (parseCommandLine(argc, argv)) {} else { return 0; }	
	cout << "\nimporting: " << ioparm.filename << endl;    // note the input filename
	buildFilenames();								// builds filename strings
	readInputFile();								// gets adjacency matrix data
	cout << "\n";
	if (ioparm.tf > gparm.n) { cout << ">> WARNING: " << ioparm.tf << " is larger than network size (" << gparm.n << "); using that instead.\n"; }
	
	// ----------------------------------------------------------------------
	// Main data structure allocation and initilization
	To		= new double	[gparm.n+1];		// number of edges with one endpoint in B
	R		= new dpair    [gparm.n+1];		// history of local modularity
	dR		= new double   [gparm.n+1];		// history of change to R
	for (int i=0; i<gparm.n+1;   i++) { To[i] = 0.0; R[i].x = 0; R[i].y = 0.0; dR[i] = 0.0; }
	
	if (ioparm.statsFlag) { collectFullStatistics(); }
	else {
	
		dpair Rmax;									// pair for finding strongest association
		int tmax		 = 0;
		double rmax     = 0.0;
		Rmax.y = -4294967296.0; Rmax.x = 0;

		// ----------------------------------------------------------------------
		// ### LocalCommunity algorithm 
		// let C be the set of vertices which are "touched"
		//	0. set R[0] = 0
		//   1. label node V as "touched"; all other nodes are "untouched"; Co[0] = 1
		//   1. add V to the boundary set; Bo[0] = 1
		//   2. for 1 < t < tf repeat the following
		//   3.    for each of the 1 < j < k neighbors of C (pending),
		//   4.       compute DeltaR_j
		//   5.    find the vertex corresponding to the maximum DeltaR_j
		//   6.    add that vertex to C, i.e., label it "touched"
		//   7.    update set of boundary vertices
		//   8.    store new R value, i.e., R[t]
		//   9.    record R[t] to file
		//   0. find time t_max which maximizes R[t]
		//   1. (optional) record subgraph C at t_max to file as inputFile_ego-subg.wpairs
		
		
		// ----------------------------------------------------------------------
		// bootstrap algorithm	
		cout << ">> starting algorithm" << endl;
		bootStrap();

		writeToJoinsFile(true);

		// ----------------------------------------------------------------------
		// Start local inference algorithm
		writeToTerminal(true);
		for (t=1; t<ioparm.tf; t++) {
			dRmax = findMaxDeltaR();						// find best join (store in dRmax)
			if (dRmax.value < -60000.0) { cout << ">> WARNING: entire component found; stopping.\n"; showPairsList(); ioparm.tf = t; break; }
			
			adjustBoundary();							// adjust the boundary
			
			Rmax = updateRStats(Rmax);					// track maximum R value

			writeToJoinsFile(false);						// write stuff to disk
			writeToTerminal(false);						// write stuff to the terminal
		} // ------------- end community merging loop
		
		// find strongest association (via d(dR/dt)/dt -- second derivative of R[t])
		double ddR = 0;
		double ddRmin = 101010101010101.0;
		for (t=1; t<ioparm.tf-1; t++) {
			ddR = dR[t+1] - dR[t];   // appx 2nd derivative
			if (ddR < ddRmin) {
				ddRmin = ddR;
				tmax = t+1;
				rmax = R[tmax].y;
			}
		}
		
		// write other stuff to disk
		if (ioparm.netFlag)		{ recordSubGraph(tmax, rmax); }
		if (ioparm.groupsFlag)   { recordGroups(tmax, rmax);   }
		// ----------------------------------------------------------------------
		// Record some results
		t1 = time(&t1);
		ofstream fout(ioparm.f_parm.c_str(), ios::app);
		fout << "---LOCAL_MODULARITY---\n";
		fout << "MAXR------:\t" << Rmax.y  << "\n";
		fout << "STEP------:\t" << Rmax.x  << "\n";
		fout << "EXIT------:\t" << asctime(localtime(&t1));
		fout.close();
	}

	cout << ">> exiting safely" << endl;
	return 1;
}


// ------------------------------------------------------------------------------------ //
// ------------------------------------------------------------------------------------ //
// ------------------------------------------------------------------------------------ //
// FUNCTION DEFINITIONS --------------------------------------------------------------- //

void adjustBoundary() {
	list *current, *currentn, *prev, *garbage, *newBL, *newPL, *newPR;
	edge *currente;
	int jmax = dRmax.target;
	int index;

	// --- updating PR lists
	// the first thing we have to do is to visit all of the vertices in the PR list of v_jmax
	// and remove references to v_jmax in their BL lists. this removal may cause that list to 
	// shrink to size 1, in which case we must add that vertex to the corresponding PL list. 
	// while we are doing this, we can delete the PR list one element at a time
	
	current = v[jmax].PR;
	while (current != NULL) {
		// first we need to eliminate jmax from the BL lists of its boundary neighbors
		// we know that these BL lists have at least two items in them because these
		// vertices are in v[jmax]'s PR list and not its PL list.
		currentn = v[current->index].BL;		// grab its BL list head
		if (currentn->index == jmax) {			// if jmax is first item
			currentn->index = currentn->next->index;	// copy data from next in line
			garbage = currentn->next;				// mark item to be deleted
			currentn->next = garbage->next;			// splice around marked item
			if (v[current->index].sBL == 2) {			// check for deleting tail
				v[current->index].BLend = currentn; }
			delete garbage;						// delete it
			v[current->index].sBL--;					// update count
		} else {							// otherwise, go look for it
			prev		= currentn;
			currentn  = currentn->next;
			while (currentn != NULL) {				// loop over its contents
				if (currentn->index == jmax) {		// if jmax is this item
					garbage = currentn;				// do list deletion
					prev->next = currentn->next;		// 
					currentn = NULL;				// 
					if (prev->next == NULL) {		// check for deleting tail
						v[current->index].BLend = prev; }
					prev     = NULL;				// 
					delete garbage;				// 
					v[current->index].sBL--;			// 
				} else {
					prev		= currentn;
					currentn  = currentn->next;
				}
			}
		}		

		// now we need to see if we have reduced any of these BL lists to size 1. if we
		// have, then we need to add the owners of the new size 1 lists to their one 
		// peripheral neighbor's PL list and find/remove it from that neighbor's PR list.
		if (v[current->index].sBL == 1) {			// reduced its BL to size 1, so
			index = v[current->index].BL->index;
			// add it to v[index]'s PL list
			newPL = new list;
			newPL->index   = current->index;
			if (index == jmax) { newPL->touched = true; }
			if (v[index].PLend == NULL) { v[index].PL = newPL; }
			else { v[index].PLend->next = newPL; }
			v[index].PLend       = newPL;
			v[index].sPL++;
			// find and remove it from v[index]'s PR list
			currentn = v[index].PR;
			if (currentn->index == current->index) { // if current->index is first item
				if (v[index].sPR > 1) {
					currentn->index = currentn->next->index;	// copy data from next in line
					garbage = currentn->next;				// mark item to be deleted
					currentn->next = garbage->next;			// splice around marked item
					if (v[index].sPR == 2) {					// check for deleting tail
						v[index].PRend = currentn; }
					delete garbage;						// delete it
				} else {
					garbage = v[index].PR;					// 
					delete garbage;						// 
					v[index].PRend = NULL;					//
					v[index].PR    = NULL;					//
				}
				v[index].sPR--;						// update count
			} else {									// otherwise, go look for it
				prev		= currentn;
				currentn  = currentn->next;
				while (currentn != NULL) {				// loop over its contents
					if (currentn->index == current->index) { // if current->index is this item
						garbage = currentn;				// do list deletion
						prev->next = currentn->next;		// 
						currentn = NULL;				// 
						if (prev->next == NULL) {			// check for deleting tail
							v[index].PRend = prev; }
						prev     = NULL;				// 
						delete garbage;				// 
						v[index].sPR--;				// 
					} else {
						prev		= currentn;
						currentn  = currentn->next;
					}
				}
			}			
		}
		
		garbage = current;
		current = current->next;
		delete garbage;			// delete PR list as we go
		v[jmax].sPR--;
	}
	if (v[jmax].sPR != 0) { cout << "ERR: v["<<jmax<<"].sPR = " << v[jmax].sPR << endl; }
	else { v[jmax].PR = NULL; v[jmax].PRend = NULL; }
	
	// --- update PL lists
	// the next thing to do is to remove, from the boundary, each element in v_jmax's PL list,
	// so long as it wasn't an element that we just added a few steps ago. we can delete v_jmax's
	// PL list, and each node's BL list as we do this
	current = v[jmax].PL;
	bool flag_temp = false;
	while (current != NULL) {
		if (!current->touched) {					// check if we just recently added it or not
			v[current->index].loc = L_INTERIOR;
			delete v[current->index].BL;			// delete the node's BL list
			v[current->index].sBL--;				// 
			v[current->index].BL = NULL;			// 
			v[current->index].BLend = NULL;		// 
			garbage = current;					// delete element in PL list as we go
			current = current->next;				// 
			delete garbage;					// 
			v[jmax].sPL--;
		} else {
			current->touched = false;
			current = current->next;				// 
			flag_temp = true;
		}
	}
	if (v[jmax].sPL != 0 && !flag_temp) { cout << "ERR: v["<<jmax<<"].sPL = " << v[jmax].sPL << endl; }
	else { v[jmax].PL = NULL; v[jmax].PLend = NULL; }

	// --- move v_jmax into BOUNDARY
	v[jmax].loc  = L_BOUNDARY;
	v[jmax].time = t;
		
	// --- try creating BL list
	// now we need to create a list of neighbors of v[jmax] that are either unknown
	// or already in the periphery. if they're unknown, we relabel them as part of the
	// periphery.
	currente = &e[jmax];
	while (currente != NULL) {
		if (v[currente->si].loc == L_UNKNOWN || v[currente->si].loc == L_PERIPHERY) {
			index	  = currente->si;
			newBL	  = new list;
			newBL->index = index;
			if (v[jmax].BLend == NULL) {
				v[jmax].BL    = newBL;
				v[jmax].BLend = newBL;
			} else {
				v[jmax].BLend->next = newBL;
				v[jmax].BLend       = newBL;
			}
			v[jmax].sBL++;
			if (v[index].loc == L_UNKNOWN) { v[index].loc = L_PERIPHERY; }
		}
		currente = currente->next;
	}
	
	// --- check if v[jmax] is actually INTERIOR, else add v[jmax] to necessary PL or PR lists.
	// with the BL list in hand, we can decide first if v[jmax] should actually be an interior
	// node. if so, we relabel it and are done here. otherwise, we have to add v[jmax] to some
	// other lists, a PL list if it only has one peripheral neighbor, or all necessary PR
	// lists if it has several.
	if (v[jmax].sBL == 0) { v[jmax].loc = L_INTERIOR; }
	else {
		current = v[jmax].BL;
		if (v[jmax].sBL == 1) {			// add to the one PL list
			newPL = new list;
			newPL->index = jmax;
			if (v[current->index].sPL == 0) { v[current->index].PL = newPL; }
			else { v[current->index].PLend->next = newPL; }
			v[current->index].PLend = newPL;
			v[current->index].sPL++;
		} else {
			while (current != NULL) {	// add to all necessary PR lists
				newPR = new list;
				newPR->index = jmax;
				if (v[current->index].sPR == 0) { v[current->index].PR = newPR; }
				else { v[current->index].PRend->next = newPR; }
				v[current->index].PRend = newPR;
				v[current->index].sPR++;
				current = current->next;
			}
		}
	}
	
	// --- updating edge count To, local modularity R
	// finally, we can update our count of the number of edges with at least one endpoint in
	// the boundary, and update our measure of the local modularity
	To[t]  = To[t-1] + dRmax.y - dRmax.Z;
	dR[t]  = dRmax.value;
	R[t].y = R[t-1].y + dR[t];
	R[t].x = dRmax.target;
	
	return;
}

// ------------------------------------------------------------------------------------

void bootStrap() {
	// the bootstrap process has several steps:
	// 1. initialize dRmax
	// 2. if gparm.v not an input, choose a random one
	// 3. mark gparm.v's location and initialize To[] count
	// 4. initialize BL, PL and PR lists
	
	// STEP 1 - initialize dRmax
	dRmax.value  = 0.0;						// 
	dRmax.target = 0;						// 
	
	// STEP 2 - set up the origin vertex v_o
	if (ioparm.v == 0) {					// if necessary, choose a random gparm.v
		gparm.v   = 1+(int)floor((double)(mtr.randExc() * (double)gparm.maxid));
		ioparm.v  = gparm.v;
		if (ioparm.mapNums) { ioparm.v--; }
	} else {
		gparm.v = ioparm.v;
		if (ioparm.mapNums) { gparm.v++; }
	}
	
	// STEP 3 - mark v_o's location, update To count
	R[0].x	  = gparm.v;				// v is first element in C
	R[0].y	  = 0.0;					// 
	if (degs[gparm.v] > 0.0) {			// 
		v[gparm.v].loc   = L_BOUNDARY;	// 
		To[0] = degs[gparm.v];			// add its edges to To
	} else {
		v[gparm.v].loc   = L_INTERIOR;	// 
	}
	v[gparm.v].time = 0;				// 

	R[0].y = 1.0/(1.0+To[0]);
	dR[0]  = R[0].y;

	// STEP 4 - initialize necessary PL, PR and BL lists
	edge *current;
	list *newBL, *newPL, *newPR;
	current = &e[gparm.v];				// add v's edges to *ne list
	v[current->si].loc  = L_PERIPHERY;		// 
	newBL			= new list;		// 
	newBL->index		= current->si;		// 
	v[gparm.v].BL		= newBL;			// add neighbor to v's BL list
	v[gparm.v].BLend    = newBL;			// point at end of BL list
	v[gparm.v].sBL++;					// 
	if (degs[gparm.v] > 1.0) {
		newPR			= new list;    // 
		newPR->index		= gparm.v;	// 
		v[current->si].PR   = newPR;		// add v to neighbor's PR list
		v[current->si].PRend= newPR;		// 
		v[current->si].sPR++;			// 
	} else {
		newPL			= new list;    // 
		newPL->index		= gparm.v;	// 
		v[current->si].PL   = newPL;		// add v to neighbor's PL list
		v[current->si].PLend= newPL;		// 
		v[current->si].sPL++;			// 
	}
	
	current = current->next;
	while (current != NULL) {				// 
		v[current->si].loc		= L_PERIPHERY; // 
		newBL				= new list;    // 
		newBL->index			= current->si; // 
		v[gparm.v].BLend->next   = newBL;		// add neighbor to v's BL list
		v[gparm.v].BLend		= newBL;		// point at end of BL list
		v[gparm.v].sBL++;					// 
		if (degs[gparm.v] > 1.0) {
			newPR				= new list;    // 
			newPR->index			= gparm.v;	// 
			v[current->si].PR		= newPR;		// add v to neighbor's PR list
			v[current->si].PRend	= newPR;		// 
			v[current->si].sPR++;					// 
		} else {
			newPL				= new list;    // 
			newPL->index			= gparm.v;	// 
			v[current->si].PL		= newPL;		// add v to neighbor's PL list
			v[current->si].PLend	= newPL;		// 
			v[current->si].sPL++;					// 
		}
		current = current->next;				// 
	}

	return;
}

// ------------------------------------------------------------------------------------

void buildFilenames() {

	// build basic path
	ioparm.f_input   = ioparm.d_in  + ioparm.filename;
	ioparm.f_parm    = ioparm.d_out + ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.info";
	ioparm.f_joins   = ioparm.d_out + ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.joins";
	ioparm.f_Rt      = ioparm.d_out + ioparm.s_scratch + "_"  + ioparm.s_label + "_ego-R.xy";
	ioparm.f_net     = ioparm.d_out + ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.pairs";
	ioparm.f_group   = ioparm.d_out + ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.groups";
	ioparm.f_stats   = ioparm.d_out + ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.stats";
	ioparm.f_statlist= ioparm.d_out + ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.statlist";
	
	if (true) { ofstream flog(ioparm.f_parm.c_str(), ios::trunc); flog.close(); }
	time_t t; t = time(&t);
	ofstream flog(ioparm.f_parm.c_str(), ios::app);
	flog << "FASTCOMMUNITY_INFERENCE_ALGORITHM\n";
	flog << "START-----:\t" << asctime(localtime(&t));
	flog << "---FILES--------\n";
	flog << "D_IN------:\t" << ioparm.d_in		<< "\n";
	flog << "D_OUT-----:\t" << ioparm.d_out		<< "\n";
	flog << "F_IN------:\t" << ioparm.filename   << "\n";
	if (ioparm.statsFlag) {
		flog << "F_STATS---:\t" << ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.stats\n";
	} else {
		flog << "F_INFO----:\t" << ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.info\n";
		flog << "F_RT------:\t" << ioparm.s_scratch + "_"  + ioparm.s_label + "_ego-R.xy\n";
		if (ioparm.joinsFlag) {
			flog << "F_JOINS---:\t" << ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.joins\n";
		}
		if (ioparm.netFlag) {
			flog << "F_NET-----:\t" << ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.pairs\n";
			flog << "F_GROUPS--:\t" << ioparm.s_scratch + "_"  + ioparm.s_label + "_ego.groups\n";
		}
	}
	flog.close();
	
	return;
}

// ------------------------------------------------------------------------------------

void collectFullStatistics() {
	// here, we will, by turns, select each vertex in the graph as the source, and run the inference
	// algorithm for ioparm.tf steps. for each run, we will compute the mean local modularity over
	// the run, and use it in the computation of the average local modularity as a function of degree.
	// this uses the data structure LS, and LSc;
	countDegrees();						// tabulate degrees of vertices
	LS  = new double [maxdeg+1];				// mean
	LSv = new double [maxdeg+1];				// variance
	LSc = new double [maxdeg+1];				// count
	double *meansq; meansq = new double [maxdeg+1];    // square of mean
	for (int i=0; i<maxdeg+1; i++) { LS[i] = 0.0; LSv[i] = 0.0; LSc[i] = 0.0; meansq[i] = 0.0; }
	dpair	Rmax;
	int		tmax, limit, k;
	double    rmax, thisLS, td;

	if (ioparm.randFlag) { limit = ioparm.r; }
	else { limit = gparm.maxid; }
	cout << "limit = " << limit << endl;

	if (true) { ofstream fstatlistinit(ioparm.f_statlist.c_str(), ios::trunc); fstatlistinit.close(); }
	for (int a=0; a<limit; a++) {
		// first choose source vertex
		if (ioparm.randFlag) {
			gparm.v   = 1+(int)floor((double)(mtr.randExc() * (double)gparm.maxid));
			ioparm.v  = gparm.v;
			if (ioparm.mapNums) { ioparm.v--; }
		} else {
			ioparm.v = a;
			gparm.v  = ioparm.v;
			if (ioparm.mapNums) { gparm.v++; }
		}
		k = gparm.v;
		
		if (e[k].so != 0) {					// start algorithm
			bootStrap();
			cout << ">> starting algorithm: " << ioparm.v << "\t(" << a << " | " << limit << ")\n";

			LSc[degree[k]] += 1.0;			// 
			tmax		= 0;					// initialize some stuff for this pass
			rmax		= 0.0;				// 
			Rmax.y    = -4294967296.0;		// 
			Rmax.x    = 0;					// 
			thisLS = R[0].y; td = 1.0;
			writeToTerminal(true);
			for (t=1; t<ioparm.tf; t++) {
				td += 1.0;					// 
				dRmax = findMaxDeltaR();			// find best join (store in dRmax)
				if (dRmax.value < -60000.0) { cout << ">> WARNING: entire component found; stopping.\n"; showPairsList(); ioparm.tf = t; break; }
				adjustBoundary();				// adjust the boundary
				writeToTerminal(false);			// write stuff to the terminal
				thisLS = R[t].y/td + ((td-1.0)/td)*thisLS;
			}
			LS[degree[k]]  = thisLS/LSc[degree[k]] + ((LSc[degree[k]]-1.0)/LSc[degree[k]])*LS[degree[k]];
			meansq[degree[k]] = (thisLS*thisLS)/LSc[degree[k]] + ((LSc[degree[k]]-1.0)/LSc[degree[k]])*meansq[degree[k]];
			cout << ">> mean R = " << thisLS << "\n";
			cout << ">> LS[" << degree[k] << "] = " << LS[degree[k]] << "\n";

			ofstream fstatlist(ioparm.f_statlist.c_str(), ios::app);
			fstatlist << degree[k] << "\t" << thisLS << "\n";
			fstatlist.close();
		
			resetVertices();				// reset all locations
		}
	}
	for (int b=0; b<maxdeg+1; b++) { LSv[b] = sqrt(meansq[b] - LS[b]*LS[b]); }
	writeToStatsFile(true);
	writeToStatsFile(false);
	
	return;
}

// ------------------------------------------------------------------------------------

tuple computeDeltaRj(const int j) {
	// to compute the dRj associated with joining the vertex v_j, we must calculate
	// several values, specifically x,y and Z.
	// this takes O(k), where k is the degree of the vertex v_j
	
	tuple dRj;
	edge *currente;
	list *current, *test;
	double x  = 0.0;						// degree of v_j which does touch C
	double y  = 0.0;						// degree of v_j which does not touch C
	double l1 = 0.0;						// number of edges from L->L
	double l3 = 0.0;						// number of edges from L->L_INTERIOR
	
	// First we compute x and y, by looking at the neighbors of v's location. Any neighboring
	// vertex which is in L_BOUNDARY increments our count of x, while otherwise it must be a
	// vertex outside the boundary. Neighbors of v_j cannot be in L_INTERIOR because vertices
	// there by definition have no neighbors outside C.
	currente = &e[j];						// 
	while (currente != NULL) {				// count number of edges attached to v_j that
		if (v[currente->si].loc == L_BOUNDARY) { x+=1.0; }//   touch B
		else { y+=1.0; }							//   do not touch B
		currente = currente->next;					// 
	}
	dRj.x = x;
	dRj.y = y;
	
	// Now we must compute Z, the number of edges which will be removed from touching B
	// as a result of joining v_j to the community. Z is composed of two counts, edges which
	// point from vertices in PL to PL (denoted as L1), and edges which point from vertices in
	// PL to L_INTERIOR (denoted as L3). Counting L3 is as simple as checking the neighboring
	// vertex's location. Counting L1 is slightly trickier, as we much check that an edge spanning
	// 
	// compute l1 and l3 by looking at the edge-lists associated with each member
	// of v_j's PL list
	current = v[j].PL;
	while (current != NULL) {
		currente = &e[current->index];
		while (currente != NULL) {
			if (v[currente->si].sBL == 1) {
				if (v[currente->si].BL->index == j) { l1 += 1.0; }  // is neighbor also in L?
			}
			else if (v[currente->si].loc == L_INTERIOR) { l3 += 1.0; }					// or, is neighbor in L_INTERIOR?
			currente = currente->next;
		}
		current = current->next;
	}
	dRj.Z = l1*0.5 + l3;		// the 0.5 is because we counted edge endpoints instead of edges

	// now we need to check to see if v_j will even end up in the boundary - if it won't, then
	// we need to increase dRj.Z by its degree
	if (y==0) { dRj.Z += x; }
	
	// finally, compute the dR_j value
//	dRj.value = ((x - dRj.Z) - (R[t-1].y * (y - dRj.Z))) / (To[t-1] + (y - dRj.Z));			// as published in PRE
	dRj.value = ((x - dRj.Z) - (R[t-1].y * (y - dRj.Z))) / (1.0 + To[t-1] + (y - dRj.Z));	// slight variation
	
	return dRj;
}

// ------------------------------------------------------------------------------------

void countDegrees() {
	// count the degree of each vertex
	edge *current;
	mindeg = 2147483000;
	maxdeg = 0;
	degree = new int [gparm.maxid];
	for (int i=0; i<gparm.maxid; i++) {
		degree[i] = 0;
		if (e[i].so != 0) {
			current = &e[i];
			while (current != NULL) {
				degree[i]++;
				current = current->next;
			}
			if (degree[i] > maxdeg) { maxdeg = degree[i]; }
			if (degree[i] < mindeg) { mindeg = degree[i]; }
		}
	}
	return;
}

// ------------------------------------------------------------------------------------

tuple findMaxDeltaR() {
	// to find the maximum deltaR value, we must examine each of the vertices in the periphery.
	// for each of those, we must loop over its set of neighbors to compute several values,
	// specifically, x and y, and l1 and l3 so that we can compute deltaR associated with
	// joining it to the boundary.
	
	// -- currently does not break ties randomly, although it probably could/should
	
	tuple dRj;
	dRmax.value = -65536.0;
	
	for (int j=0; j<gparm.maxid; j++) {
		if (v[j].loc == L_PERIPHERY) {
			dRj = computeDeltaRj(j);				// compute dR_j
			if (dRj.value > dRmax.value) {		// is dR_j a new maximum?
				dRmax.value  = dRj.value;		//   if so, store it
				dRmax.target = j;				// 
				dRmax.x      = dRj.x;			// 
				dRmax.y      = dRj.y;			// 
				dRmax.Z      = dRj.Z;			// 
			}
		}
	}	
	return dRmax;
}

// ------------------------------------------------------------------------------------

bool parseCommandLine(int argc,char * argv[]) {
	int argct = 1;
	string temp, ext;
	string::size_type pos;
	char **endptr;
	long along;
	int count;
	
	// Description of commandline arguments
	// -f <filename>    give the target .pairs file to be processed
	// -k <int>		number of steps to run the algorithm
	// -s <int>		(optional) initial vertex (default: random one)
	// -NET			(optional) record a subgraph
	// -GROUPS		(optional) record list of vertices in group
	// -JOINS			(optional) record list of joins
	// -l <text>		the text label for this run; used to build output filenames

	
	// -t <int>		period of timer for reporting progress of computation to screen
	// -v --v ---v		differing levels of screen output verbosity
	// -o <directory>   directory for file output
	
	if (argc <= 1) { // if no arguments, return statement about program usage.
		cout << "by Aaron Clauset (aaron@cs.unm.edu), copyright 2005.\n\n";
		cout << "This program runs the ego-centric communityinference algorithms due to Clauset ";
		cout << "on an input graph in the .pairs format. The full description of this algorithm ";
		cout << "and its results are described fully in cond-mat/05?????. The program ";
		cout << "requires the input network connectivity to be formatted in the following specific ";
		cout << "way: the graph must be simple and connected, where each edge is written on ";
		cout << "a line in the format 'u v' (e.g., 3481 3483).\n";
		cout << "To run the program, you must specify the input network file (-f file.pairs). ";
		cout << "Additionally, you can differentiate runs on the same input file with a label ";
		cout << "(-l test_run) which is imbedded in all corresponding output files. ";
		cout << "Further, one must specify (-s integer) the ego-vertex at which the inference is centered, ";
		cout << "and a number of steps to run the algorithm (-k integer).\n";
		cout << "The algorithm will write the local modularity as a function of time. ";
		cout << "Examples:\n";
		cout << "  ./LocalCommunityB -l label -s 1 -k 100 -JOINS -f network.pairs \n";
		cout << "  ./LocalCommunityB -l label -STATS -k 250 -f network.pairs \n";
		cout << "  ./LocalCommunityB -l label -STATS -k 100 -r 1000 -f network.pairs \n";
		cout << "\n";
		return false;
	}
	while (argct < argc) {
		temp = argv[argct];
		
		if (temp == "-f") {			// input file name
			argct++;
			temp = argv[argct];
			ext = ".pairs";
			pos = temp.find(ext,0);
			if (pos == string::npos) { cout << " Error: Input file must have terminating .pairs extension.\n"; return false; }
			ext = "/";
			count = 0; pos = string::npos;
			for (int i=0; i < temp.size(); i++) { if (temp[i] == '/') { pos = i; } }
			if (pos == string::npos) {
				ioparm.d_in = "";
				ioparm.filename = temp;
			} else {
				ioparm.d_in = temp.substr(0, pos+1);
				ioparm.filename = temp.substr(pos+1,temp.size()-pos-1);
			}
			ioparm.d_out = ioparm.d_in;
			// now grab the filename sans extension for building outputs files
			for (int i=0; i < ioparm.filename.size(); i++) { if (ioparm.filename[i] == '.') { pos = i; } }
			ioparm.s_scratch = ioparm.filename.substr(0,pos);
		} else if (temp == "-l") {	// s_label
			argct++;
			if (argct < argc) { ioparm.s_label = argv[argct]; }
			else { " Warning: missing modifier for -l argument; using default.\n"; }
			
		} else if (temp == "-t") {	// timer value
			argct++;
			if (argct < argc) {
				along = strtol(argv[argct],endptr,10);
				ioparm.timer = atoi(argv[argct]);
				cout << ioparm.timer << endl;
				if (ioparm.timer == 0 || strlen(argv[argct]) > temp.length()) {
					cout << " Warning: malformed modifier for -t; using default.\n"; argct--;
					ioparm.timer = 20;
				} 
			} else {
				cout << " Warning: missing modifier for -t argument; using default.\n"; argct--;
			}
		} else if (temp == "-o") {    // target output DIRECTORY
			argct++;
			if (argct < argc) { ioparm.d_out = argv[argct]; }
			else { " Warning: missing modifier for -o argument; using default.\n"; }	
		} else if (temp == "-k") {	// number of steps to run the algorithm
			argct++;
			if (argct < argc) {
				ioparm.tf = atoi(argv[argct]);
				if (ioparm.tf == 0) {
					cout << " Warning: malformed modifier for -k; using default.\n"; argct--;
				} 
			} else {
				cout << " Warning: missing modifier for -k argument; using default.\n"; argct--;
			}
		} else if (temp == "-s") {	// ego-centric vertex
			argct++;
			if (argct < argc) {
				ioparm.v = atoi(argv[argct]);
				if (ioparm.v == 0) {
					cout << " Warning: malformed modifier for -s; using default.\n"; argct--;
				} 
			} else {
				cout << " Warning: missing modifier for -s argument; using default.\n"; argct--;
			}
		} else if (temp == "-r") {	// number of random samples
			argct++;
			if (argct < argc) {
				ioparm.r = atoi(argv[argct]);
				ioparm.randFlag = true;
				if (ioparm.r == 0) {
					cout << " Warning: malformed modifier for -r; using default.\n"; argct--;
				}
			} else {
				cout << " Warning: missing modifier for -r argument; using default.\n"; argct--;
			}
		}
		else if (temp == "-NET")		{    ioparm.netFlag		= true;		}
		else if (temp == "-GROUPS")   {    ioparm.groupsFlag   = true;		}
		else if (temp == "-JOINS")    {    ioparm.joinsFlag    = true;		}
		else if (temp == "-STATS")    {    ioparm.statsFlag    = true;		}
		else if (temp == "-v")		{    ioparm.textFlag	= 1;			}
		else if (temp == "--v")		{    ioparm.textFlag	= 2;			}
		else if (temp == "---v")		{    ioparm.textFlag	= 3;			}
		else {  cout << "Unknown commandline argument: " << argv[argct] << endl; }
		argct++;
	}
	
//	cout << "starting point is " << ioparm.v << endl;
//	cin >> pauseme;
	return true;
}

// ------------------------------------------------------------------------------------

void readInputFile() {
	
	// temporary variables for this function
	int numnodes = 0;
	int numlinks = 0;
	int s,f,t;
	edge **last;
	edge *newedge;
	edge *current;								// pointer for checking edge existence
	bool existsFlag;							// flag for edge existence
	time_t t1; t1 = time(&t1);
	time_t t2; t2 = time(&t2);
	
	// First scan through the input file to discover the largest node id. We need to
	// do this so that we can allocate a properly sized array for the sparse matrix
	// representation.
	cout << " scanning input file for basic information." << endl;
	int minindex = 2;
	cout << "  edgecount: [0]"<<endl;
	ifstream fscan(ioparm.f_input.c_str(), ios::in);
	while (fscan >> s >> f) {					// read friendship pair (s,f)
		numlinks++;							// count number of edges
		if (f < s) { t = s; s = f; f = t; }		// guarantee s < f
		if (f > numnodes) { numnodes = f; }		// track largest node index
		if (s < minindex) { minindex = s; }		// track smallest node index

		if (t2-t1>ioparm.timer) {				// check timer; if necessarsy, display
			cout << "  edgecount: ["<<numlinks<<"]"<<endl;
			t1 = t2;							// 
			ioparm.timerFlag = true;				// 
		}									// 
		t2=time(&t2);							// 
		
	}
	fscan.close();
	if (ioparm.timerFlag) { cout << "  edgecount: ["<<numlinks<<"]"<<endl; }
	if (minindex == 0) { ioparm.mapNums = true; } else { ioparm.mapNums = false; }
	if (ioparm.mapNums) { gparm.maxid = numnodes+2; } // store maximum index
	else { gparm.maxid = numnodes+1; }
	elist = new edge   [2*numlinks];				// create requisite number of edges
	int ecounter = 0;							// index of next edge of elist to be used

	// Now that we know numnodes, we can allocate the space for the sparse matrix, and
	// then reparse the file, adding edges as necessary.
	v		= new vertex [gparm.maxid];			// create vertices array
	e		= new edge   [gparm.maxid];			// (unordered) sparse adjacency matrix
	last		= new edge*  [gparm.maxid];			// list of pointers to the last edge in each row
	degs		= new double [gparm.maxid];			// list of degreees for each vertex
	for (int i=0; i<gparm.maxid; i++) { degs[i] = 0.0; }
	numnodes = 0;								// numnodes now counts number of actual used node ids
	numlinks = 0;								// numlinks now counts number of bi-directional edges created
	ioparm.timerFlag = false;					// reset timer
	
	cout << " now building network from input file." << endl;
	cout << "  edgecount: [0]"<<endl;
	ifstream fin(ioparm.f_input.c_str(), ios::in);
	while (fin >> s >> f) {
		if (ioparm.mapNums) { s++; f++; }			// increment s,f to prevent using e[0]
		if (f < s) { t = s; s = f; f = t; }		// guarantee s < f
		numlinks++;							// increment link count (preemptive)
		if (e[s].so == 0) {						// if first edge with s, add s and (s,f)
			e[s].so = s;						// 
			e[s].si = f;						// 
			last[s] = &e[s];					//    point last[s] at self
			numnodes++;						//    increment node count
			degs[s]+=1.0;						//    increment vertex degree
			v[s].index = s;					//    make vertex exist
		} else {								//    try to add (s,f) to s-edgelist
			current = &e[s];					// 
			existsFlag = false;					// 
			while (current != NULL) {			// check if (s,f) already in edgelist
				if (current->si==f) {			// 
					existsFlag = true;			//    link already exists
					numlinks--;				//    adjust link-count downward
					break;					// 
				}							// 
				current = current->next;			//    look at next edge
			}								// 
			if (!existsFlag) {					// if not already exists, append it
				newedge = &elist[ecounter++];		//    grab next-free-edge
				newedge -> so = s;				// 
				newedge -> si = f;				// 
				last[s] -> next = newedge;		//    append newedge to [s]'s list
				last[s]         = newedge;		//    point last[s] to newedge
				degs[s] += 1.0;				//    increment vertex degree
			}								// 
		}									// 
		
		if (e[f].so == 0) {						// if first edge with f, add f and (f,s)
			e[f].so = f;						// 
			e[f].si = s;						// 
			last[f] = &e[f];					//    point last[s] at self
			numnodes++;						//    increment node count
			degs[f] += 1.0;					//    increment vertex degree
			v[f].index = f;					//    make vertex exist
		} else {								// try to add (f,s) to f-edgelist
			if (!existsFlag) {					//    if (s,f) wasn't in s-edgelist, then
				newedge = &elist[ecounter++];		//       (f,s) not in f-edgelist
				newedge -> so = f;				// 
				newedge -> si = s;				// 
				last[f] -> next = newedge;		//    append newedge to [f]'s list
				last[f]		 = newedge;		//    point last[f] to newedge
				degs[f] += 1.0;				//    increment vertex degree
			}								// 
		}									
		existsFlag = false;						// reset existsFlag
		if (t2-t1>ioparm.timer) {				// check timer; if necessarsy, display
			cout << "  edgecount: ["<<numlinks<<"]"<<endl;
			t1 = t2;							// 
			ioparm.timerFlag = true;				// 
		}									// 
		t2=time(&t2);							// 
		
	}
	if (ioparm.timerFlag) { cout << "  edgecount: ["<<numlinks<<"]"<<endl; }
	fin.close();
		
	// Now we record our work in the parameters file, and exit.
	ofstream fout(ioparm.f_parm.c_str(), ios::app);
	fout << "---NET_STATS----\n";
	if (ioparm.mapNums) {
		fout << "MAXID-----:\t" << gparm.maxid-2 << "\n"; 
	} else {
		fout << "MAXID-----:\t" << gparm.maxid-1 << "\n"; 
	}
	fout << "NUMNODES--:\t" << numnodes << "\n";
	fout << "NUMEDGES--:\t" << numlinks << "\n";
	fout.close();

	gparm.m = numlinks;							// store actual number of edges created
	gparm.n = numnodes;							// store actual number of nodes used
	return;
}

// ------------------------------------------------------------------------------------

void recordGroups(const int tmax, const double Rmax) {

	cout << ">> recording group at R[" << tmax << "] = " << Rmax <<"\n";
	
	// record the list of vertices in C
	ofstream fgroup(ioparm.f_group.c_str(), ios::trunc);
	fgroup << "GROUP[ "<<ioparm.v<<" ][ " << tmax+1 <<" ]\n"; // external format
	for (int i=1; i<gparm.maxid; i++) {
		if (v[i].time<=tmax) {
			if (ioparm.mapNums) { fgroup << i-1 << "\n"; }
			else { fgroup << i << "\n"; }
		}
	}
	fgroup.close();
	
	return;
}

// ------------------------------------------------------------------------------------

void recordSubGraph(const int tmax, const double Rmax) {
	// this function retraces the algorithm's steps up to Rmax.x = t_max, and records 
	// a) the list of vertices in the group at t_max, and
	// b) the .pairs subgraph associated with that group

	// find the tmax such that R[tmax] is the maximum of R[i] for all i < tf
	cout << ">> recording subgraph at R[" << tmax << "] = " << Rmax <<"\n";
	
	edge *current;
	// record the subgraph of edges added up to tmax (inclusive)
	ofstream fnet(ioparm.f_net.c_str(), ios::trunc);
	for (int i=1; i<gparm.maxid; i++) {
		if (v[i].time<=tmax) {
			current = &e[i];
			while (current != NULL) {
				if (v[current->si].time <= tmax) {
					if (ioparm.mapNums) {
						fnet << i-1 << "\t" << current->si-1 << "\n";
					} else {
						fnet << i << "\t" << current->si << "\n";
					}
				}
				current = current->next;
			}
		}
	}
	fnet.close();
	
	return;
}

// ------------------------------------------------------------------------------------

void resetVertices() {

	delete [] v;
	v = new vertex [gparm.maxid];
	
	for (int i=0; i<gparm.maxid; i++) {
		To[i]	= 0.0;
		R[i].x    = 0;
		R[i].y    = 0.0;
		dR[i]	= 0.0;
	}	
	return;
}

// ------------------------------------------------------------------------------------

void showPairsList() {
	edge *current; int degr; int bdeg = 0;
	for (int i=0; i<gparm.maxid; i++) {
		if (e[i].so > 0) {
			cout << "["<<i<<"] ";
			switch (v[i].loc) {
				case L_UNKNOWN:   cout << "U ( "; break;
				case L_PERIPHERY: cout << "P ( "; break;
				case L_BOUNDARY:  cout << "B ( "; break;
				case L_INTERIOR:  cout << "C ( "; break;
			}
			current = &e[i];
			degr = 0;
			while (current != NULL) {
				if (v[i].loc == L_BOUNDARY) { bdeg++; }
				degr++;
				cout << current->si << " ";
				current = current -> next;
			}
			cout << ")\t" << degr << "\n";
		}
	}
	cout << "bdeg = " << bdeg << endl;
	cin >> pauseme;
	return;
}

// ------------------------------------------------------------------------------------

dpair updateRStats(dpair Rmax) {
	
	if (R[t].y > Rmax.y) {
		Rmax.y = R[t].y;
		Rmax.x = t;
	}								// track maximum R value

	return Rmax;
}

// ------------------------------------------------------------------------------------

void writeToJoinsFile(const bool flag) {
	if (flag) {
		if (ioparm.joinsFlag) {
			ofstream fjoinsinit(ioparm.f_joins.c_str(), ios::trunc);
			fjoinsinit << "0\t";
			if (ioparm.mapNums) { fjoinsinit << gparm.v-1; }
			else { fjoinsinit << gparm.v; }
			fjoinsinit << "\t"<< R[0].y << "\n";
			fjoinsinit.close();
		}
		ofstream frtinit(ioparm.f_Rt.c_str(), ios::trunc);
		frtinit << "0\t"<< R[0].y << "\n";
		frtinit.close();
	} else {
		if (ioparm.joinsFlag) {
			ofstream fjoins(ioparm.f_joins.c_str(), ios::app);		// open file for writing this join
			fjoins << t << "\t";
			if (ioparm.mapNums) { fjoins << R[t].x-1; }
			else { fjoins << R[t].x; }
			fjoins << "\t" << R[t].y << "\n";
			fjoins.close();
		}
		ofstream frt(ioparm.f_Rt.c_str(), ios::app);					// open file for writing this R[t]
		frt << t << "\t" << R[t].y << "\n";						// 
		frt.close();
	}
	return;
}

// ------------------------------------------------------------------------------------

void writeToStatsFile(const bool flag) {
	if (flag) { ofstream fstatsinit(ioparm.f_stats.c_str(), ios::trunc); fstatsinit.close(); }
	else {
		ofstream fstats(ioparm.f_stats.c_str(), ios::app);
		for (int i=mindeg; i<maxdeg+1; i++) { fstats << i << "\t" << LS[i] << "\t" << LSv[i] << "\n"; }
		fstats.close();
	}
	return;
}
// ------------------------------------------------------------------------------------

void writeToTerminal(const bool flag) {
	int temp, bsize;
	if (flag) {
		cout << "t\tR[t]      \t change            \tkbar_B\n";
		cout << "----------------------------------------------------------------\n";
		cout << "0\t";
		temp = cout.width();
		cout.width(10);
		cout << left << R[0].y << "\t =(";
		cout.width(2);
		cout << left << gparm.v << " ";
		cout.width(12);
		cout << dR[0];
		cout.width(temp);
		cout << ")";
		bsize = 0;
		for (int q=0; q<gparm.maxid; q++) { if (v[q].loc == L_BOUNDARY) { bsize++; } }
		cout << "\t";
		cout.width(6);
		cout << To[0] / (double)bsize << "\t";
		cout.width(temp);
		cout << bsize << "\n";
	} else {
		cout <<t<<"\t";
		temp = cout.width();
		cout.width(10);
		cout << left << R[t].y;
		if (R[t].y >= R[t-1].y) { cout << "\t +("; } else { cout << "\t -("; }
		cout.width(2);
		cout << left << R[t].x << " ";
		cout.width(12);
		cout << dR[t];
		cout.width(temp);
		cout << ")"; // << endl;
		bsize = 0;
		for (int q=0; q<gparm.maxid; q++) { if (v[q].loc == L_BOUNDARY) { bsize++; } }
		cout << "\t";
		cout.width(7);
		cout << left << To[t] / (double)bsize << "\t";
		cout.width(temp);
		cout << left << bsize << "\n";
		if (R[t].y > 1.001) { cout << ">> WARNING: R[" << t << "] exceeds boundary of 1.0; graph structure is suspect.\n"; }
	}
	return;
}

// ------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------




