[h,s] = fastaread('rask_et_al_DBLa.fasta');

for i=1:length(h)
    % 1 RAJ116
    % 2 IGH
    % 3 PFCLIN
    % 4 IT4
    % 5 DD2
    % 6 HB3
    % 7 Reference
    if ~isempty(strfind(h{i},'RAJ'))
        par(i) = 1;
    elseif ~isempty(strfind(h{i},'IGH'))
        par(i) = 2;
    elseif ~isempty(strfind(h{i},'PFCLIN'))
        par(i) = 3;
    elseif ~isempty(strfind(h{i},'IT4'))
        par(i) = 4;
    elseif ~isempty(strfind(h{i},'DD2'))
        par(i) = 5;
    elseif ~isempty(strfind(h{i},'HB3'))
        par(i) = 6;
    else
        par(i) = 7;
    end
end

