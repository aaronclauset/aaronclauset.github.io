
If you use these data, you should cite this paper:

H. A. Dawah, B. A. Hawkins and M. F. Claridge, "Structure of the parasitoid communities of grass-freeding chalcid wasps." Journal of Animal Ecology 64, 708-720 (1995)

http://www.jstor.org/discover/10.2307/5850
